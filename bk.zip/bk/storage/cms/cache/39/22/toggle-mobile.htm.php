<?php 
class Cms5c98ff33d1e95438044498_fb2d435800794aa39289e33c3dfc3742Class extends Cms\Classes\PartialCode
{

}
