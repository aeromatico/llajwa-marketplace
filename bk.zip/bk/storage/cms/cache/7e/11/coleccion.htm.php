<?php 
class Cms5c8fd43a7d441152033705_1950b0c6325397e995d01de1eec327eeClass extends Cms\Classes\PageCode
{

}
