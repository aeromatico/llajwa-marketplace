<?php 
class Cms5c9e5f63f0523788862992_ba1aa81e00a2f35015ecde7b94037a33Class extends Cms\Classes\PageCode
{

}
