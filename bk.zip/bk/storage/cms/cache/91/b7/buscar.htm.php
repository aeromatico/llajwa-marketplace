<?php 
class Cms5c8eec25edd7c115144393_973f9fb7a124eff2b3953849bf4a7860Class extends Cms\Classes\PartialCode
{

}
