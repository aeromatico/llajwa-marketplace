<?php 
class Cms5c8eec25eb902650828471_6c1b14bc882adbf569f7f6650b3ab9fcClass extends Cms\Classes\PartialCode
{

}
