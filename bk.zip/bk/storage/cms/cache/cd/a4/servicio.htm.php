<?php 
class Cms5c8fef99ce531102988273_5d522b047dfc20b14249781b5f73b0dbClass extends Cms\Classes\PageCode
{
public function onStart()
{  
  $this['url_slug'] = $this->param('slug');
}
}
