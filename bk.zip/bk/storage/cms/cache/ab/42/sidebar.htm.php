<?php 
class Cms5c8eec25eaf88855413684_591476c2d0e3f5a68de7a9eb74e5163bClass extends Cms\Classes\PartialCode
{

}
