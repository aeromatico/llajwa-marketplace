<?php 
class Cms5c9e5cb86a08d530676411_95bf611372f5c31f7b1e092fa85aa4adClass extends Cms\Classes\PageCode
{

}
