<?php 
class Cms5c98ff33be6f5292390527_f81c00a7fe8ee4a93a2b1da5da7ca9a5Class extends Cms\Classes\LayoutCode
{

}
