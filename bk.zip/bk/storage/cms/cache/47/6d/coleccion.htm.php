<?php 
class Cms5c9e5c297ec77313239313_1e4c9d354e646410b6a6c5c2547df83dClass extends Cms\Classes\PageCode
{

}
