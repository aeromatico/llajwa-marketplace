<?php 
class Cms5c9918a63d50d310602224_1b33a26c0068eedc43c85bb2b62fce42Class extends Cms\Classes\PageCode
{

}
