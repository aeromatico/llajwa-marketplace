<?php 
class Cms5c9d543bdeff4155640712_ea8760375a75588f8f005aff11c5ad40Class extends Cms\Classes\PartialCode
{

}
