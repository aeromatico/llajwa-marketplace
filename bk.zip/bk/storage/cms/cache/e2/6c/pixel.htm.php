<?php 
class Cms5c9d733dee85c966182670_0984a14effa2235250fa737fa437577dClass extends Cms\Classes\PartialCode
{

}
