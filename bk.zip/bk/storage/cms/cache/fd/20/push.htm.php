<?php 
class Cms5c8eec24eaa24421604386_10426ee7ba13a9b4d3c35421b6d27496Class extends Cms\Classes\PartialCode
{

}
