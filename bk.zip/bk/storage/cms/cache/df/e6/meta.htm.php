<?php 
class Cms5c8eec24e770e432648451_b30a01ca1fadbc204eaaaa50950e4a40Class extends Cms\Classes\PartialCode
{

}
