<?php 
class Cms5c9cd18ac846d259866315_7abf1fe652c36be67758a01d54b2d61dClass extends Cms\Classes\PartialCode
{

}
