<?php 
class Cms5c8f06838c571168743087_604403722b1d981d5b7b8cc2bc4af539Class extends Cms\Classes\PageCode
{

}
