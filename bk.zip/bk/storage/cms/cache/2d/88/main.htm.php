<?php 
class Cms5c9e42611abb9723794718_cee8b00beb56d6d7bce80bca0b873562Class extends Cms\Classes\PartialCode
{

}
