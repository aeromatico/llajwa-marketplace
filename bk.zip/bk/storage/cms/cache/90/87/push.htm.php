<?php 
class Cms5c98ff33cbfb5514396979_f2c698078a20c533e5ac355f4b9b2907Class extends Cms\Classes\PartialCode
{

}
