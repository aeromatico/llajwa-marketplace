<?php 
class Cms5c98ff33d3e5b664936185_3da61d5d5e0967be4ade23dc2966a35cClass extends Cms\Classes\PartialCode
{

}
