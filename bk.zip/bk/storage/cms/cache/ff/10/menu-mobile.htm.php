<?php 
class Cms5c98ff33cd288896755713_c4555fcba6eb25f2d9a95abef7d33883Class extends Cms\Classes\PartialCode
{

}
