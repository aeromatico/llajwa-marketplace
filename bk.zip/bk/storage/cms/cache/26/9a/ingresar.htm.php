<?php 
class Cms5c8fd439c0bc6901123017_1fe36829e4f4eb47b2614ee1bfe23596Class extends Cms\Classes\PageCode
{

}
