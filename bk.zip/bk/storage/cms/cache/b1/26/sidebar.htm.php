<?php 
class Cms5c98ff33d1223264273472_3738b04aed9488789f3ba2e5a9bd7ebfClass extends Cms\Classes\PartialCode
{

}
