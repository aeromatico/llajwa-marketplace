<?php 
class Cms5c98ff33c72c1257626349_efaa70d7d62be36494f7868f69f015f7Class extends Cms\Classes\PartialCode
{

}
