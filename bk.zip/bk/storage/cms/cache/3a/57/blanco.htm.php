<?php 
class Cms5c9a3acab29e9681315774_daf69b758a4058f637e7093c33c51aa3Class extends Cms\Classes\PageCode
{

}
