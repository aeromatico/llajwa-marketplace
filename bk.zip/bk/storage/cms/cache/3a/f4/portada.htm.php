<?php 
class Cms5c98ff33beea2357291929_a8fec48d1d5ef209ecfe42420d3a7a19Class extends Cms\Classes\PageCode
{

}
