<?php 
class Cms5c91cc5d708dd620849055_d689a62dcd7620237c0e16af6fb47843Class extends Cms\Classes\PageCode
{

}
