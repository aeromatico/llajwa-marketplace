<?php 
class Cms5c8eec24eb529814724686_aea4daae210b94e0526405f70af6f342Class extends Cms\Classes\PartialCode
{

}
