<?php 
class Cms5c9e44329502a903918807_e023db7ea99f23a5f94ca4f7bf3aefe2Class extends Cms\Classes\PageCode
{

}
