<?php 
class Cms5c91cbc178407621690952_ef23d7b93b2b879aa8b570e067ecf772Class extends Cms\Classes\PageCode
{

}
