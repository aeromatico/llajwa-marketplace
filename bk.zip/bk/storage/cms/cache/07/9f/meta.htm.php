<?php 
class Cms5c9e41f035446632175668_85cd6fd65d3c6bb43aaff14a2babc620Class extends Cms\Classes\PartialCode
{

}
