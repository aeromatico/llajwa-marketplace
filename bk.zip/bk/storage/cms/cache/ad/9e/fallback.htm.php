<?php 
class Cms5c99725b8207c373230528_34c7a120389e405cf942be9209e3c41fClass extends Cms\Classes\LayoutCode
{

}
