<?php 
class Cms5c9e178d3d95e049753829_75547be972a164cd3a606a12834e7900Class extends Cms\Classes\PartialCode
{

}
