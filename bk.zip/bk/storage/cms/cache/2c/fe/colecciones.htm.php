<?php 
class Cms5c98ff33d2a0e105519050_82b03e08690a4b33177f4679b7010143Class extends Cms\Classes\PartialCode
{

}
