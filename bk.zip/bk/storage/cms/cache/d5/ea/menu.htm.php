<?php 
class Cms5c8eec25ed241129087708_5f7ec96c50f6e3bbfd702808a57bbd2eClass extends Cms\Classes\PartialCode
{

}
