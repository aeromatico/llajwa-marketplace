<?php 
class Cms5c98ff33d4c65218444171_9ec9f8fff3cd4cdaf95a66060ca10781Class extends Cms\Classes\PartialCode
{

}
