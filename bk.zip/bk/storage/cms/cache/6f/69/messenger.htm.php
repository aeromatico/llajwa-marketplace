<?php 
class Cms5c9d6ed6e65e9543836549_33f7b11361f4bf8f2df8c112215865c1Class extends Cms\Classes\PartialCode
{

}
