<?php 
class Cms5c8eec25ec050534168061_fe81f3464776b3aa915a735bf18d4ac2Class extends Cms\Classes\PartialCode
{

}
