<?php return [
    'plugin' => [
        'name' => 'Manager',
        'description' => ''
    ]
];